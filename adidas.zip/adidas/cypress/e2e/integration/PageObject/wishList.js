class addWishList{

    navigate(){
        cy.visit('https://www.adidas.co/', { headers: { "Accept-Encoding": "gzip, deflate" }, "Accept": "application/json, text/plain, */*",
        "User-Agent": "axios/0.27.2" })
        cy.get(':nth-child(2) > .teaser-card-redesign___12z8g > .teaser-card-wrapper___1FO3l > .teaser-card-content___2bHKo > .teaser-media___3IqY8').click()
        cy.url().should('eq', 'https://www.adidas.co/italia?sort=newest-to-oldest')
        cy.get('.gl-modal__close > [data-testid="close"]').click()
        cy.get('[data-index="0"] > :nth-child(1) > .plp-container-with-masking > :nth-child(1) > :nth-child(1) > .glass-product-card-container > .glass-product-card > .glass-product-card__assets > .glass-product-card__wishlist > div > [data-testid="wishlist-inactive"]').click()
        cy.get('#login-register-auto-flow-input').clear().type('jdarredondo10@gmail.com{enter}')
        // cy.get('.email-section-main-content___3I-P4').click()
        // cy.wait(3000)
        // cy.get('.email-section-form___2lE3f > .gl-cta > [data-testid="arrow-right-long"]').click()
        
 
              
        
    }


    
}

export default addWishList