import addWishList from "../e2e/integration/PageObject/wishList"
describe("Wish List", function(){
    it("Login with previously added wish list", function(){
         const wishList = new addWishList();   
         wishList.navigate();   

    })



})